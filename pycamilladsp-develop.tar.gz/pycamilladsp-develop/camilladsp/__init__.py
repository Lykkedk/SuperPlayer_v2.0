from camilladsp.camilladsp import CamillaConnection, CamillaError
